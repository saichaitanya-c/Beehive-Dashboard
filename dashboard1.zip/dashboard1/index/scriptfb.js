// Firebase Configuration
const firebaseConfig = {
    apiKey: "AIzaSyCc2CHbWxVlmLtGGF5L5tY_VxOnfuRo5FU",
    authDomain: "test1-3e832.firebaseapp.com",
    databaseURL: "https://test1-3e832-default-rtdb.europe-west1.firebasedatabase.app",
    projectId: "test1-3e832",
    storageBucket: "test1-3e832.firebasestorage.app",
    messagingSenderId: "518093938096",
    appId: "1:518093938096:web:c29cb0c1981327777e4a75",
    measurementId: "G-C0X95TBMCL"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const database = firebase.database();

// DOM Elements
const container = document.getElementById('container');
const signUpButton = document.getElementById('signUp');
const signInButton = document.getElementById('signIn');
const forgotPasswordLink = document.getElementById('forgotPasswordLink');
const backToSignInButton = document.getElementById('backToSignIn');

// Event Listeners for Panel Transitions
signUpButton.addEventListener('click', () => {
    container.classList.add("right-panel-active");
});

signInButton.addEventListener('click', () => {
    container.classList.remove("right-panel-active");
});

forgotPasswordLink.addEventListener('click', (e) => {
    e.preventDefault();
    container.classList.add("forgot-password-active");
});

backToSignInButton.addEventListener('click', (e) => {
    e.preventDefault();
    container.classList.remove("forgot-password-active");
});

// Helper Function to Show Toast Notifications
function showToast(message) {
    alert(message); // Replace with a custom toast notification if desired
}

/// Register User
document.getElementById('registerForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const name = document.getElementById("registerName").value.trim();
    const email = document.getElementById("registerEmail").value.trim();
    const password = document.getElementById("registerPassword").value.trim();
    const uniqueId = document.getElementById("registerUniqueId").value.trim();

    if (!name || !email || !password || !uniqueId) {
        Swal.fire({
            title: "Missing Information",
            text: "All fields are required!",
            icon: "warning",
            showClass: {
                popup: `
                    animate__animated
                    animate__fadeInUp
                    animate__faster
                `
            },
            hideClass: {
                popup: `
                    animate__animated
                    animate__fadeOutDown
                    animate__faster
                `
            }
        });
        return;
    }

    auth.createUserWithEmailAndPassword(email, password)
        .then((userCredential) => {
            const user = userCredential.user;

            // Send Email Verification
            user.sendEmailVerification()
                .then(() => {
                    Swal.fire({
                        title: "Email Verification Sent",
                        text: "Verification email sent. Please check your inbox.",
                        icon: "success",
                        showClass: {
                            popup: `
                                animate__animated
                                animate__fadeInUp
                                animate__faster
                            `
                        },
                        hideClass: {
                            popup: `
                                animate__animated
                                animate__fadeOutDown
                                animate__faster
                            `
                        }
                    });
                })
                .catch((verificationError) => {
                    Swal.fire({
                        title: "Error",
                        text: `Error sending verification email: ${verificationError.message}`,
                        icon: "error",
                        showClass: {
                            popup: `
                                animate__animated
                                animate__fadeInUp
                                animate__faster
                            `
                        },
                        hideClass: {
                            popup: `
                                animate__animated
                                animate__fadeOutDown
                                animate__faster
                            `
                        }
                    });
                });

            // Save user details to Firebase Database
            return database.ref("users/" + user.uid).set({
                name: name,
                email: email,
                uniqueId: uniqueId,
            });
        })
        .then(() => {
            Swal.fire({
                title: "Registration Successful",
                text: "Registration successful! Please verify your email before logging in.",
                icon: "success",
                showClass: {
                    popup: `
                        animate__animated
                        animate__fadeInUp
                        animate__faster
                    `
                },
                hideClass: {
                    popup: `
                        animate__animated
                        animate__fadeOutDown
                        animate__faster
                    `
                }
            });
            document.getElementById('registerForm').reset();
            container.classList.remove("right-panel-active"); // Switch to login view
        })
        .catch((error) => {
            Swal.fire({
                title: "Registration Failed",
                text: error.message,
                icon: "error",
                showClass: {
                    popup: `
                        animate__animated
                        animate__fadeInUp
                        animate__faster
                    `
                },
                hideClass: {
                    popup: `
                        animate__animated
                        animate__fadeOutDown
                        animate__faster
                    `
                }
            });
        });
});

// Login User
// Login User
document.getElementById('loginForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const email = document.getElementById("loginEmail").value.trim();
    const password = document.getElementById("loginPassword").value.trim();

            

    if (!email || !password) {
        Swal.fire({
            title: 'Missing Information',
            text: 'Email and Password are required!',
            icon: 'warning',
            customClass: {
                popup: 'animated tada'
            }
        });
        return;
    }

    auth.signInWithEmailAndPassword(email, password)
        .then((userCredential) => {
            const user = userCredential.user;
            sessionStorage.setItem('authenticated', 'true'); // Set authenticated flag

            if (user.emailVerified) {
                database.ref("users/" + user.uid).once("value")
                    .then((snapshot) => {
                        const name = snapshot.val().name;
                        const uniqueId = snapshot.val().uniqueId;

                        localStorage.setItem('uniqueId', uniqueId);

                        Swal.fire({
                            title: 'Welcome!',
                            text: `Hello, ${name}!`,
                            icon: 'success',
                            customClass: {
                                popup: 'animated tada'
                            }
                        });

                        // Redirect based on Unique ID
                        let dashboardUrl;
                        if (uniqueId === '2490315') {
                            dashboardUrl = `dashboard1.html?node=${uniqueId}`;
                        } else if (uniqueId === '2490316') {
                            dashboardUrl = `dashboard2.html?node=${uniqueId}`;
                        } else if (uniqueId === '2490317') {
                            dashboardUrl = `dashboard3.html?node=${uniqueId}`;
                        } else {
                            dashboardUrl = `defaultDashboard.html?node=${uniqueId}`;
                        }

                        setTimeout(() => {
                            window.location.href = dashboardUrl;
                        }, 3000); // Wait for the alert to be acknowledged
                    })
                    .catch((dbError) => {
                        Swal.fire({
                            title: 'Error',
                            text: `Error retrieving user data: ${dbError.message}`,
                            icon: 'error',
                            customClass: {
                                popup: 'animated tada'
                            }
                        });
                    });
            } else {
                Swal.fire({
                    title: 'Email Not Verified',
                    text: 'Please verify your email before logging in.',
                    icon: 'warning',
                    customClass: {
                        popup: 'animated tada'
                    }
                });
            }
        })
        .catch((error) => {
            // Extract and format the error message
            let errorMessage = 'An error occurred while logging in.';
            if (error && error.message) {
                if (error.message.includes('INVALID_LOGIN_CREDENTIALS')) {
                    errorMessage = 'Invalid login credentials. Please check your email and password and try again.';
                } else if (error.message.includes('EMAIL_NOT_FOUND')) {
                    errorMessage = 'This email is not registered. Please check your email or create a new account.';
                } else if (error.message.includes('INVALID_PASSWORD')) {
                    errorMessage = 'The password you entered is incorrect. Please try again.';
                } else {
                    errorMessage = error.message; // Default to Firebase's message
                }
            }

            // Show SweetAlert2 with the custom error message
            Swal.fire({
                title: 'Login Failed',
                text: errorMessage,
                icon: 'error',
                customClass: {
                    popup: 'animated tada'
                }
            });
        });
});
// Send Password Reset Email
document.getElementById('forgotPasswordForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const email = document.getElementById("forgotEmail").value.trim();

    if (!email) {
        Swal.fire({
            title: 'Missing Information',
            text: 'Email is required to reset your password.',
            icon: 'warning',
            customClass: {
                popup: 'animated tada'
            }
        });
        return;
    }

    auth.sendPasswordResetEmail(email)
        .then(() => {
            Swal.fire({
                title: 'Success!',
                text: 'Password reset link has been sent to your email.',
                icon: 'success',
                customClass: {
                    popup: 'animated tada'
                }
            });

            // Reset the form and hide the forgot-password container
            document.getElementById('forgotPasswordForm').reset();
            container.classList.remove("forgot-password-active");
        })
        .catch((error) => {
            // Extract and format the error message
            let errorMessage = 'An error occurred while sending the reset link.';
            if (error && error.message) {
                if (error.message.includes('EMAIL_NOT_FOUND')) {
                    errorMessage = 'This email is not registered. Please check your email and try again.';
                } else {
                    errorMessage = error.message; // Default to Firebase's error message
                }
            }

            // Display the error message using SweetAlert2
            Swal.fire({
                title: 'Error',
                text: errorMessage,
                icon: 'error',
                customClass: {
                    popup: 'animated tada'
                }
            });
        });
});
