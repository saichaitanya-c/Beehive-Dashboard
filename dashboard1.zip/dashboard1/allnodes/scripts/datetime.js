function updateDateTime() {
    let now = new Date();
    let locale = "eng";  // German locale
    let options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    let timeOptions = { hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' };

    // Generate formatted time with seconds
    let formattedTime = now.toLocaleTimeString(locale, timeOptions);
    let timeParts = formattedTime.split(':');
    let hour = parseInt(timeParts[0], 10);
    let amPm = hour >= 12 && hour < 24 ? 'PM' : 'AM';

    // Adjust for 12-hour format manually
    hour = hour % 12;
    hour = hour ? hour : 12;  // the hour '0' should be '12'

    document.getElementById('time').textContent = hour + ':' + timeParts[1] + ':' + timeParts[2].substring(0, 2); // Extracting seconds and adjusting format
    document.getElementById('ampm').textContent = amPm;
    document.getElementById('day').textContent = now.toLocaleDateString(locale, options);
}

setInterval(updateDateTime, 1000);
updateDateTime(); // Initial call to set date/time immediately on load