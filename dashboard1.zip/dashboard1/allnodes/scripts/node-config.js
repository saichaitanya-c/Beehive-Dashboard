

// Change language dynamically based on the language selector this is for the language 
function changeLanguage() {
    const lang = document.getElementById("languageSelect")?.value;

    if (!lang) {
        console.error("Language selector not found.");
        return;
    }

    if (!translations[lang]) {
        console.error(`Language "${lang}" is not supported.`);
        return;
    }

    const elements = document.querySelectorAll("[id]");
    elements.forEach(element => {
        const translationKey = element.id;
        if (translations[lang][translationKey]) {
            element.textContent = translations[lang][translationKey];
        }
    });
}

// Sample translations object for testing
const translations = {
    en: {
        dashboardTitle: "Smart Beehive Monitoring Dashboard",
        downloadApkLink: "Download APK",
        allNodesLink: "All Nodes",
        contactUsLink: "Contact Us",
        logoutLink: "Logout",
        nodeSelectLabel: "Select Node:",
        temperatureTitle: "Temperature",
        humidityTitle: "Humidity",
        HornetDetectionTitle: "Hornet Detection",
        temperatureAlert: "Temperature Exceeds Safe Levels!",
        humidityAlert: "Humidity Exceeds Safe Levels!",
        HornetDetectionAlert: "Hornet Detected!",
        footer: "Smart Beehive Monitoring - Stay Informed, Stay Connected"
    },
    de: {
        dashboardTitle: "Smartes Bienenstock-Überwachungsdashboard",
        downloadApkLink: "APK herunterladen",
        allNodesLink: "Alle Knoten",
        contactUsLink: "Kontaktieren Sie uns",
        logoutLink: "Abmelden",
        nodeSelectLabel: "Knoten auswählen:",
        temperatureTitle: "Temperatur",
        humidityTitle: "Feuchtigkeit",
        HornetDetectionTitle: "Hornissenerkennung",
        temperatureAlert: "Temperatur überschreitet sichere Werte!",
        humidityAlert: "Feuchtigkeit überschreitet sichere Werte!",
        HornetDetectionAlert: "Hornissenerkennung erkannt!",
        footer: "Intelligente Bienenstocküberwachung - Bleiben Sie informiert, bleiben Sie verbunden"
    }
};

// Ensure the language selector triggers the function on change
document.addEventListener('DOMContentLoaded', () => {
    const languageSelect = document.getElementById("languageSelect");
    if (languageSelect) {
        languageSelect.addEventListener("change", changeLanguage);
        changeLanguage(); // Initialize with the default language
    } else {
        console.error("Language selector element not found.");
    }
});
