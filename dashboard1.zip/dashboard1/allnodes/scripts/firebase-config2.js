// Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyDngL5UmUK2eQ3IpRV_kvP-OxzX1jXSjBo",
    authDomain: "beehive2-c773f.firebaseapp.com",
    databaseURL: "https://beehive2-c773f-default-rtdb.europe-west1.firebasedatabase.app",
    projectId: "beehive2-c773f",
    storageBucket: "beehive2-c773f.firebasestorage.app",
    messagingSenderId: "290002038033",
    appId: "1:290002038033:web:94f5cd8a1a7742f80b70b0",
    measurementId: "G-9YJCGEQ5HP"
  };

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

// Function to update the data display for the selected node
function updateNodeDisplay(data) {
    // Update temperature and handle loading
    const temperatureElement = document.getElementById('temperature');
    const tempLoading = temperatureElement.querySelector('.loading');
    if (data.temperature !== undefined) {
        temperatureElement.textContent = `${data.temperature} °C`;
        if (tempLoading) tempLoading.style.display = 'none';
    } else {
        if (tempLoading) tempLoading.style.display = 'block';
    }

    // Update humidity and handle loading
    const humidityElement = document.getElementById('humidity');
    const humidLoading = humidityElement.querySelector('.loading');
    if (data.humidity !== undefined) {
        humidityElement.textContent = `${data.humidity} %`;
        if (humidLoading) humidLoading.style.display = 'none';
    } else {
        if (humidLoading) humidLoading.style.display = 'block';
    }

    // Update weight and handle loading
    const weightElement = document.getElementById('weight');
    const weightLoading = weightElement.querySelector('.loading');
    if (data.weight !== undefined) {
        weightElement.textContent = `${data.weight} kg`;
        if (weightLoading) weightLoading.style.display = 'none';
    } else {
        if (weightLoading) weightLoading.style.display = 'block';
    }

    // Update hornet detection status and handle loading
    const hornetElement = document.getElementById('HornetDetection');
    const hornetLoading = hornetElement.querySelector('.loading');
    if (data.hornetDetected !== undefined) {
        hornetElement.textContent = data.hornetDetected ? "Hornet detected" : "No hornet detected";
        if (hornetLoading) hornetLoading.style.display = 'none';
    } else {
        if (hornetLoading) hornetLoading.style.display = 'block';
    }
}


// Function to load data for the selected node
function loadNodeData() {
    const nodeSelect = document.getElementById('nodeSelect');
    const selectedNode = nodeSelect.value;
    const nodeRef = firebase.database().ref(`2490316/${selectedNode}`);

    nodeRef.on('value', (snapshot) => {
        if (snapshot.exists()) {
            const data = snapshot.val();
            updateNodeDisplay(data);
        } else {
            console.error(`No data found for ${selectedNode}`);
            // Clear the display or show an error message
            updateNodeDisplay({temperature: 'N/A', humidity: 'N/A', weight: 'N/A', hornetDetected: false});
        }
    });
}

// Initial load of data for the default selected node
document.addEventListener('DOMContentLoaded', () => {
    loadNodeData();
});

