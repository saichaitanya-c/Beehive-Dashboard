// Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyCc2CHbWxVlmLtGGF5L5tY_VxOnfuRo5FU",
    authDomain: "test1-3e832.firebaseapp.com",
    databaseURL: "https://test1-3e832-default-rtdb.europe-west1.firebasedatabase.app",
    projectId: "test1-3e832",
    storageBucket: "test1-3e832.firebasestorage.app",
    messagingSenderId: "518093938096",
    appId: "1:518093938096:web:c29cb0c1981327777e4a75",
    measurementId: "G-C0X95TBMCL"
  };

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

// Function to update the data display for the selected node
function updateNodeDisplay(data) {
    document.getElementById('temperature').textContent = `${data.temperature} °C`;
    document.getElementById('weight').textContent = `${data.weight} kg`;
    document.getElementById('HornetDetection').textContent = data.hornetDetected ? "Hornet detected" : "No hornet detected";
}

// Function to load data for the selected node
function loadNodeData() {
    const nodeSelect = document.getElementById('nodeSelect');
    const selectedNode = nodeSelect.value;
    const nodeRef = firebase.database().ref(`2490315/${selectedNode}`);

    nodeRef.on('value', (snapshot) => {
        if (snapshot.exists()) {
            const data = snapshot.val();
            updateNodeDisplay(data);
        } else {
            console.error(`No data found for ${selectedNode}`);
            // Clear the display or show an error message
            updateNodeDisplay({temperature: 'N/A', battery: 'N/A', weight: 'N/A', hornetDetected: false});
        }
    });
}

// Initial load of data for the default selected node
document.addEventListener('DOMContentLoaded', () => {
    loadNodeData();
});

