const { AgCharts } = agCharts;

// Initialize Firebase
const firebaseConfig = {
  apiKey: "AIzaSyCc2CHbWxVlmLtGGF5L5tY_VxOnfuRo5FU",
  authDomain: "test1-3e832.firebaseapp.com",
  databaseURL: "https://test1-3e832-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "test1-3e832",
  storageBucket: "test1-3e832.firebasestorage.app",
  messagingSenderId: "518093938096",
  appId: "1:518093938096:web:c29cb0c1981327777e4a75",
  measurementId: "G-C0X95TBMCL"
};
firebase.initializeApp(firebaseConfig);

const database = firebase.database();

// Fetch data from Firebase
function fetchData() {
  return new Promise((resolve, reject) => {
    const ref = database.ref("2490315");
    ref.once("value", (snapshot) => {
      const data = snapshot.val();
      const formattedData = Object.keys(data).map((nodeKey) => {
        const nodeData = data[nodeKey];
        return {
          node: nodeKey,
          temperature: nodeData.temperature,
          humidity: nodeData.humidity,
          weight: nodeData.weight,
        };
      });
      resolve(formattedData);
    }, reject);
  });
}

fetchData().then((chartData) => {
  const options = {
    container: document.getElementById("myChart"),
    data: chartData,
    title: {
      text: "BeeHive Monitoring Data",
    },
    footnote: {
      text: "Source: Smart BeeHive System",
    },
    series: [
      {
        type: "line",
        xKey: "node", // Replace with time if necessary
        yKey: "temperature",
        tooltip: {
          renderer: ({ datum }) => ({
            content: `Temperature: ${datum.temperature.toFixed(2)}°C`,
          }),
        },
        title: "Temperature",
      },
      {
        type: "line",
        xKey: "node", // Replace with time if necessary
        yKey: "humidity",
        tooltip: {
          renderer: ({ datum }) => ({
            content: `Humidity: ${datum.humidity.toFixed(2)}%`,
          }),
        },
        title: "Humidity",
      },
      {
        type: "line",
        xKey: "node", // Replace with time if necessary
        yKey: "weight",
        tooltip: {
          renderer: ({ datum }) => ({
            content: `Weight: ${datum.weight.toFixed(2)}kg`,
          }),
        },
        title: "Weight",
      },
    ],
    axes: [
      {
        position: "bottom",
        type: "category", // Use "time" if using timestamps
        title: {
          text: "Node",
        },
      },
      {
        position: "left",
        type: "number",
        title: {
          text: "Value",
        },
      },
    ],
  };

  AgCharts.create(options);
});
